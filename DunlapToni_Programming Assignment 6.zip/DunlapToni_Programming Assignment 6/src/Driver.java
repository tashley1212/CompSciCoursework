/*
 * @author: Toni Dunlap
 * date: 11/15/2018
 * Assignment: Project 6, COMP 2370
 * Discussed project with others in class
 */

import java.io.File;
//import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


public class Driver {
	public static void main(String[] args) {

		//assigns the text file to a number in the command line
		File filename = new File (args[0]);
		//Because I use this line, I noticed it caused issues with my try catch block. So I ended up not needing the try/catch

		//initializing variables
		String bFord, dijkstra;
		Graph graph = new Graph();
		float bTime, dTime;

		//variables to assist with reading in text files and outputting the info.
		Scanner inputStream = null;
		PrintWriter dataOut = null;

		try
		{
			inputStream = new Scanner(filename);
			Scanner line = null;

			while (inputStream.hasNext()) {
				line = new Scanner(inputStream.nextLine());
				String vValue = line.next();
				graph.addVertex(vValue, Integer.MAX_VALUE);

				while (line.hasNext()) {
					graph.addEdge(vValue, line.next(), line.nextFloat());
				}
			}
			inputStream.close();
		}
		catch(FileNotFoundException e) {
			System.out.println("Cannot open file: " + filename);
			System.out.println(e.getMessage());
			System.exit(0);
		}

		//Timer initialization and calculations for Bellman Ford alg	
		CpuTimer cp1 = new CpuTimer();
		bFord = graph.BellmanFord();
		bTime = (float) cp1.getElapsedCpuTime();
		System.out.println(graph.getNumOfV() + ", " + graph.getNumOfEdges() + ", " + "\"B\", " + (float)bTime + ", " + "\"" + args[0] + "\"");

		//Timer initialization and calculations for Dijkstra's alg
		CpuTimer cp2 = new CpuTimer();

		dijkstra = graph.Dijkstra();

		dTime = (float) cp2.getElapsedCpuTime();

		System.out.println(graph.getNumOfV() + ", " + graph.getNumOfEdges() + ", " + "\"D\", " + (float)dTime + ", " + "\"" + args[0] + "\"");

		//attempting to output the information found into a text file
		try {
			dataOut = new PrintWriter(new File(args[0] + ".bout"));
			dataOut.write(bFord);
			dataOut.flush();
			dataOut.close();
			dataOut = new PrintWriter (new File(args[0] + ".dout"));
			dataOut.write(dijkstra);
			dataOut.flush();
			dataOut.close();
		}
		catch (FileNotFoundException e) {
			System.out.println("Cannot complete action: " +e.getMessage());
			System.exit(0);
		}
	}
}
