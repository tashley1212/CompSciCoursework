/*
 * @author: Toni Dunlap
 * date: 11/15/2018
 * Assignment: Project 6, COMP 2370
 * Discussed project with others in class
 */

import java.util.ArrayList;

public class Vertex <E>
{	
	private E ID;
	private double sourceDistance;
	private ArrayList<Edge<E>> list; //made to store a list of vertices
	private Vertex <E> predecessor; //predecessor variable
	//	private String vID; // 
	//	private Edge edge;

	public Vertex(E ID, double sourceDistance)
	{
		this.ID = ID;
		this.sourceDistance = sourceDistance;
		predecessor = null;
		list = new ArrayList<>();

	}
	// below is filled with getters and setters to be used in the Graph class to obtain info related to vertices & edges
	public E getValue() {
		return ID;
	}

	public double getDistanceFromS() {
		return sourceDistance;
	}
	public void addEdge(Edge <E> e) {
		list.add(e);

	}

	public ArrayList<Edge<E>> getEdges() {
		return list;
	}

	public void setDistanceFromS(double d) {
		sourceDistance = d;
	}
	//	//Below creates several getters and sets, in addition to a method to add and remove edges from vertex list
	//	public void setFinishTime(double t)
	//	{
	//		fT = t;
	//	}
	//	
	//	public void setDiscoveryTime(double t)
	//	{
	//		dT = t;
	//	}

	//	public void setVertexID(String ID) {
	//		vID = ID;
	//	}
	//	
	public void setP(Vertex<E> p) {
		predecessor = p;
	}

	//	public Object getVertexID()
	//	{		
	//		return vID;
	//	}


	public Vertex<E> getPredecessor() {
		return predecessor;
	}

//	public int getSize()
//	{
//		return list.size();
//	}
//	
//	public double getDiscoveryTime()
//	{
//		return dT;
//	}
//	
//	public double getfTime()
//	{
//		return fT;
//	}
//Inner class made for edges
	public static class Edge <E>{
	private String sVertex; //source vertex
	private String dVertex; //destination vertex
	private double weight; //edge weight

	public Edge(String sVertex, String dVertex, double weight) {
		//initializes variables
		this.sVertex = sVertex;
		this.dVertex = dVertex;
		this.weight = weight;
	}

	//below are getter methods to be used in the Graph class
	public String getSourceV() {
		return sVertex;
	}

	public double getEdgeweight() {
		return weight;
	}
	public String getDestinationV() {
		return dVertex;
	}
}
}

//		public void setDestination(Vertex v) {
//			destination = v;
//		}

//		public void setEdgeWeight(int weight) {
//			this.weight = weight;
//		}
//		public String toString()
//		{
//			StringBuilder sb = new StringBuilder();
//			sb.append(weight);
//			sb.append("miles to ");
//			sb.append(destination.getVertexID());
//			sb.append(";		");
//			return sb.toString();
//
//		}
//}
//
//
//	public int getNumEdges() {
//		// TODO Auto-generated method stub
//		return list.size();
//	}
