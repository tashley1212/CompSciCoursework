/*
 * @author: Toni Dunlap
 * date: 11/15/2018
 * Assignment: Project 6, COMP 2370
 * Discussed project with others in class
 */
import java.util.HashMap;
import java.util.ArrayList;
import java.util.PriorityQueue;


//import Vertex.Edge;

import java.lang.StringBuilder;

public class Graph {

	private int numV; //number of vertices
	private int numEdges; //number of edges
	private String sVertex; //source vertex
	private HashMap <String, Vertex<String>> v; //using hash map to access information
	private ArrayList <Vertex.Edge<String>> edges; //an array list for storing the edges
	//	public static ArrayList<Vertex> graph;
	//	public static final int MAX = 99999;
	//	public ArrayList<Vertex> dVertSet;

	public Graph() {
		//initializing all my variables
		numV = 0;
		numEdges = 0;
		sVertex = null;
		v = new HashMap<>();
		edges = new ArrayList<>();

	}
	//adds vertex to list
	public void addVertex(String vertex, double sourceD)
	{
		if (!v.containsKey(vertex)) {
			if (numV == 0) {
				sVertex = vertex;
			}
			Vertex <String> newV = new Vertex<>(vertex, sourceD);
			v.put(vertex, newV);
			numV++;
		}
	}

	//getter methods
	public int getNumOfV() {
		return numV;
	}

	public int getNumOfEdges() {
		return numEdges;
	}

	//adds Edges to graph
	public void addEdge (String sVert, String dVert, double weight) {
		Vertex.Edge <String> newEdge = new Vertex.Edge<>(sVert, dVert, weight);
		edges.add(newEdge);
		v.get(sVert).addEdge(newEdge);
		numEdges++;
	}

	//Bellman Ford algorithm method
	public String BellmanFord() {
		initializeSingleSource();
		//initializing source
		v.get(sVertex).setDistanceFromS(0);

		for(int i = 1; i < numV; i++) {

			for(int j = 0; j < numEdges; j++) {
				//calls the relaxation process
				relax(edges.get(j).getSourceV(), edges.get(j).getDestinationV(), edges.get(j).getEdgeweight());
			}
		}

		for(int j = 0; j < numEdges; j++) {
			//stores edge info, including weights, sources, and destinations
			Vertex<String> value1 = v.get(edges.get(j).getSourceV());
			Vertex<String> value2 = v.get(edges.get(j).getDestinationV());
			double weight = edges.get(j).getEdgeweight();

			//checks for negative cycles
			if(value2.getDistanceFromS() > (value1.getDistanceFromS() + weight) || value2.getDistanceFromS() == Integer.MAX_VALUE) {
				System.out.println("Negative cycle identified");
				return null;
			}
		}
		//Helps with the formating for output
		StringBuilder sb = new StringBuilder();
		for (String key: v.keySet()) {
			sb.append(key + " " + (double) v.get(key).getDistanceFromS() + "\n");
		}
		return sb.toString();
	}


	//	public boolean checkNegativeCycles(Vertex s) {
	//		for(int i = 0; i < graph.size(); i++) {
	//			for (int j = 0; j < s.getNumEdges(); j++) {
	//				double sourceKey = s.getDiscoveryTime();
	//				double edgeWeight = s.getEdge(j).getEdgeweight();
	//				double sum = sourceKey + edgeWeight;
	//				double dKey = s.getEdge(j).getDestination().getDiscoveryTime();
	//				if (sum < dKey) {
	//					System.out.print("Negative cycles detected");
	//					return true; //neg cycles detected
	//				}
	//			}
	//			
	//		}
	//		return false; //no neg cycles detected
	//	}

	//Dijkstra's algorithm
	public String Dijkstra() {
		initializeSingleSource();

		//initializes source
		Vertex <String> s = v.get(sVertex);
		s.setDistanceFromS(0);

		//adds vertices to a priority queue
		PriorityQueue <String> q = new PriorityQueue<>();
		q.add(s.getValue());

		while (!q.isEmpty()) {
			String queue = q.poll();

			//calls the relaxation process
			for (Vertex.Edge<String> e : v.get(queue).getEdges()) {
				String value = e.getDestinationV();
				double weight = e.getEdgeweight();
				if (relax(queue, value, weight)) {
					if(q.contains(value)) {
						q.remove(value);
					}
					q.add(value);
				}
			}
		}
		
		//Helps with the formating for output
		StringBuilder sb = new StringBuilder();

		for (String key: v.keySet()) {

			sb.append(key + " " + (double)v.get(key).getDistanceFromS() + "\n");

		}

		return sb.toString();

	}


	//	public Vertex extractMin(Queue q) {
	//		Vertex min = (Vertex) q.dequeue();
	//		return min;
	//	}


	public void initializeSingleSource() {
		for (String key: v.keySet()) {
			//initialize program to set all distances to infinity and not assigning predecessors
			v.get(key).setDistanceFromS(Integer.MAX_VALUE);
			v.get(key).setP(null);
		}

	}

	//process for relaxing the edges. Each algorithm calls this method
	public boolean relax (String sVertex, String dVertex, double weight) {
		Vertex<String> value1 = v.get(sVertex); //storing the source vertex
		Vertex<String> value2 = v.get(dVertex); //storing the destination vertex

		//completing the calculation to see if we need to adjust the weights and change predecessor info
		if (value2.getDistanceFromS() > (value1.getDistanceFromS() + weight) || value2.getDistanceFromS() == Integer.MAX_VALUE) {
			value2.setDistanceFromS(value1.getDistanceFromS() + weight);
			value2.setP(value1); //changes predecessor
			return true;
		}
		else {
			return false;
		}
	}
}
