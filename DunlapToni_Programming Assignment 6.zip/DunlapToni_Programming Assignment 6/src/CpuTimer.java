/**
 * @author Mike Goss (mikegoss@cs.du.edu)
 * 
 */

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;

public class CpuTimer
{
	private final ThreadMXBean bean;
	private final double startTimeSeconds;
	
	public CpuTimer()
	{
		bean = ManagementFactory.getThreadMXBean();
		assert bean.isCurrentThreadCpuTimeSupported():"getCurrentThreadCpuTime not supported by this JVM, use a different JVM";
	
		startTimeSeconds = 1.0e-9 * (double) bean.getCurrentThreadCpuTime();
	}

	public double getElapsedCpuTime()
	{
		return 1.0e-9 * (double) bean.getCurrentThreadCpuTime() - startTimeSeconds;
	}	
}
