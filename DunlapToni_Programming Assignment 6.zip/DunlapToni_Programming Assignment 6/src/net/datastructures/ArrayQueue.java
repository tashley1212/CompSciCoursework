package net.datastructures;

public class ArrayQueue<E> implements Queue<E> {

	//the size of the array
	public static final int CAPACITY = 100;
	private E[]data;
	//keeps track of where the front of the queue is
	private int f;
	//keeps track of the current size
	private int sz;
	
	
	public ArrayQueue(int capacity)
	{
		f = 0;
		sz = 0;
		data = (E[]) new Object[capacity];
	}
	
	public ArrayQueue()
	{
		this(CAPACITY);
	}
	
	public int size()
	{
		return sz;
	}
	
	public boolean isEmpty()
	{
		return sz == 0;
	}
	
	//inserts object at the end of the queue
	public void enqueue(E e) throws IllegalStateException
	//a natural java exception so that we don't have to make our own
	{
		if(sz == data.length)
		{
			throw new IllegalStateException("Queue is full");
		}
		
		//R stands for the �rear� of the queue
		//the next available location after the end of the queue
		int r = (f + sz) % data.length;
		data[r] = e;
		sz++;
	}
	
	public E first()
	{
		if(isEmpty())
		{
			return null;
		}
		
		return data[f];
	}
	
	public E dequeue()
	{
		if(isEmpty())
		{
			return null;
		}
		
		E answer = data[f];
		//dereferences the location
		data[f] = null;
		f = (f + 1) % data.length;
		sz--;
		return answer;
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder("(");
		int k = f;
		
		for(int i = 0; i < sz; i ++)
		{
			//formatting
			if(i > 0)
			{
				sb.append(", ");
			}
			
			//move through the array
			sb.append(data[k]);
			k = (k + 1) % data.length;
		}
		sb.append(")");
		return sb.toString();
	}
}
