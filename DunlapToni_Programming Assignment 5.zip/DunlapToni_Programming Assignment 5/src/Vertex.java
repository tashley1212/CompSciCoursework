
import java.util.ArrayList;

public class Vertex
{	
	public ArrayList<Integer> vList; //made to store a list of vertices
	public int dT; //discovery time variable
	public int fT; //final time variable
	public String color; // b, g, w;
	public Vertex parent; //variable for the predecessor vertex
	
	public Vertex()
	{
		vList = new ArrayList<Integer>(); //initalizes list
		//initalizes variables to 0
		dT = 0;
		fT = 0;
		color = "WHITE";
//		b = "BLACK";
//		g = "GRAY";
//		w = "WHITE";
		parent = null;
	}
	
	//Below creates several getters and sets, in addition to a method to add and remove edges from vertex list
	public void setfTime(int t)
	{
		fT = t;
	}
	
	public void setDiscoveryTime(int t)
	{
		dT = t;
	}
	public void setParent(Vertex p) {
		parent = p;
	}
	public void addVertex(int i)
	{
		vList.add(i);
	}
	
	public void removeVertex(int i)
	{
		vList.remove(i);
	}
	
	public int getVertex(int i)
	{		
		return vList.get(i);
	}
	public int returnSource() {
		return vList.get(0);
	}
	public int getDestination() {
		return vList.get(1);
	}
	public int getSize()
	{
		return vList.size();
	}
	
	public int getDiscoveryTime()
	{
		return dT;
	}
	
	public int getfTime()
	{
		return fT;
	}
	public void setColor(String c) {
		color = c;
		
	}
	public String getColor() {
		return color;
	}
	
	//Converts vertices to string so it can be printed out
	public String toString()
	{
		StringBuilder sb = new StringBuilder();

		for(int i = 0; i < vList.size(); i++)
		{
			sb.append(vList.get(i));
			//spaces for formatting
			sb.append("   ");
		}
		return sb.toString();
	}
	
	public String colorPrint() {
		if((dT != 0)&&(fT != 0)) {
			color = "BLACK";
			return color;
		}
		if((dT == 0)&&(fT == 0)) {
			color = "WHITE";
			return color;
		}
		if((dT != 0)&&(fT == 0)) {
			color = "GRAY";
			return color;
		}
		return "NO COLOR SET";
	}
}
