import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Driver {
	public static void main(String[] args) {
		
		//assigns the text file to a number in the command line
		String filename = args[0];
		
		//initializing variables
		int n = 0; //number of vertices
		Graph graph = new Graph(n);
		
		
		//try/catch block to read data from file into ArrayList
		Scanner inputStream = null;
		try
		{
			inputStream = new Scanner(new FileInputStream(filename));
						
			//number of vertices is first number in file
			n = inputStream.nextInt();
			System.out.println("Graph size (n) is: " + n);
			graph.setGraphSize(n);
			
			//At first, the initial number at the top of text file is read into the file. Now are reading in the number pairs 
										
				//for(int i = 0; i <= n; i++)
				//{
			
					Graph a = new Graph(n); //new variable for strongly connected components
					
					while(inputStream.hasNextInt()){
						//reading in information for vertex and then creating a vertex variable
					Vertex v = new Vertex();
					
					//first number will be the source for the list of vertices
					int source = inputStream.nextInt();					
					System.out.println("The next source is: " + source);
					
					//next number will be the edge, to be stored in the scc variable alongside it's vertex
					int nextEdge = inputStream.nextInt();
					System.out.println("Next destination is : " + nextEdge);
					
					v.addVertex(source);
					a.addEdge(source, nextEdge);
					
					v.toString();
					graph.addVertex(v);					
					System.out.println(); //for spacing to make the output easier to read
					
					
					//System.out.println(inputStream.hasNextInt());
				}
			inputStream.close();
			System.out.println("Below is the list of Strongly Connected Components based on the text file:");
			a.printSCCs();
		}
		
		
		
		catch(FileNotFoundException e)
		{
			System.out.println("Cannot open file: " + filename);
			System.exit(0);
		}
						
		
	}

}
