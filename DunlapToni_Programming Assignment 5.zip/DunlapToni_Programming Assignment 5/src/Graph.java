import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;
/*
 * @author: Toni Dunlap
 * date: 11/4/2018
 * Assignment: Project 5, COMP 2370
 */
public class Graph {

	//Notes from TA conversation:at the beginning of the transpose method you're gonna make a new graph... 
	//Look through the vertexs of the old graph. Grab the ID from each vertex
	//Then, loop thru again the vertexs in the adjaceny list of the vertex that you're currently on
	// add an edge between your vertex in your current loop, or I guess your second loop, and your first loop
	// Doing a swapping of the source and destination

	private int n; //number of vertices

	public static ArrayList<Vertex> adjList;
	public static ArrayList<Vertex> adjListcopy;
	public static LinkedList<Integer> SCClist[];
	public static int time; //overall time ticker
	public static int timeD; //discovery time
	public static int timeF; //finish time

	/*
	 * The way the color coding works based on timing
	 * white; discover time = 0; finish = 0
	 * gray; discover != 0; finish = 0
	 * black; discover !=0; finish != 0;
	 * 
	 * 
	 */
	public Graph(int v)
	{
		n = v;
		SCClist = new LinkedList[v];
		for (int i=0; i<v; i++) {
			SCClist[i] = new LinkedList();
		}
		adjList = new ArrayList<Vertex>();	//new list filled with vertices	
	}

	public void setGraphSize(int vertices)
	{
		n = vertices;
	}

	//adds vertex to list
	public void addVertex(Vertex v)
	{
		adjList.add(v);
	}
	public void addEdge(int v, int e) {
		SCClist[v].add(e);
	}

	public Vertex getVertex (int i) {
		Vertex v = adjList.get(i);
		//returns the vertex on the list at the location "i"
		return v;
	}

	public int getSize() {
		return adjList.size();
	}

//	//Checks the adjacent list to find an element 'j" at vertex "i"
//	public boolean hasEdge(int i, int j)
//	{
//		Vertex v = adjList.get(i);
//
//		for(int x = 0; x < v.getSize(); x++)
//		{
//			int elm = v.getVertex(x);
//
//			if(elm == j)
//			{
//				System.out.println("Vertex has edge: " + j);
//				return true;
//			}
//		}
//		return false;
//	}



	public String toString()
	{
		StringBuilder sb = new StringBuilder();

		for(int i = 0; i < adjList.size(); i++)
		{

			Vertex vert = adjList.get(i);

			sb.append(vert.toString());

		}


		return sb.toString();

	}

		public void DFS() {
			for (int i = 0; i < adjListcopy.size(); i++) {

				Vertex v = adjListcopy.get(i);

				//setting unvisited vertices to "white"
				v.setColor("WHITE");
				v.setParent(null);
				time = 0;

				//storing current color info
				String current = v.getColor();
				
				if (current.equals("WHITE")) {
					DFSVisit(adjListcopy, v);
				}
			}
		}

		public void DFSVisit(ArrayList<Vertex> g, Vertex u)
		{

			time++;
			timeD = time;
			//setting color to gray, meaning we're not finished searching the edges
			u.setColor("GRAY");
//
//			int destination = u.getDestination();
//
//			Vertex v = g.getVertex(destination);
//			String vColor = v.getColor();
			
			// for(i = 0; i < u.vList.size(); i++){
			for(Integer t : u.vList) {
				// t = u.vList[i]
				Vertex v = g.get(t);
				if(v.color.equals("WHITE")) {
					v.setParent(u);
					DFSVisit(g, v);
				}
			}



			u.setColor("BLACK");
			time++;
			timeF = time;
		}
		
		public void printSCCs() {
			Stack<Integer> stack = new Stack<Integer>();
			//Find all not visited vertices and mark them
			for (int i = 0; i < n; i++) {
				adjList.get(i).setColor("WHITE");
			}
			
			//Fill the stack with the vertices based on their finishing times
			for (int i = 0; i< n; i++) {
				if (adjList.get(i).getColor() == "WHITE") {
					fillOrder(i, adjList, stack);
				}
			}
			//Creating a reversed graph
			Graph gr = transpose();
			
			//Can mark all vertices as not visited for 2nd DFS
			for (int i = 0; i < n; i++) {
				adjListcopy.get(i).setColor("WHITE");
			}
			
				
				while (stack.empty() == false) {
				int vertex = (int) stack.pop();
				
				if(adjListcopy.get(vertex).getColor() == "WHITE") {
					
					gr.DFS();
					System.out.println(gr);
				}
			}
		}

		// Method that is responsible for filling the stack in the proper order
		private void fillOrder(int v, ArrayList<Vertex> adjList2, Stack<Integer> stack) {
			adjList.get(v).setColor("BLACK");
			
			Iterator<Integer> i = SCClist[v].iterator();
			
			while (i.hasNext()) {
				int h = i.next();
				if(adjList.get(h).getColor() == "WHITE") {
					fillOrder(h,adjList2, stack);
				}
			}
			stack.push(new Integer(v));
			adjListcopy = adjList;
			//System.out.println(adjListcopy);
			//System.out.println(adjList);
		}

		//Reversing the graph
		public Graph transpose() {
			Graph tGraph = new Graph(n);
			for (int v = 0; v < n; v++) {
				Iterator<Integer> i = SCClist[v].iterator();
				while(i.hasNext()) {
					tGraph.SCClist[i.next()].add(v);
				}
			}
			return tGraph;
		}
	}
//public Graph transpose(Graph g) {
//	
//	Graph tGraph = new Graph(g.getSize());
//	for (int v = 0; v < n; v++) {
//		tGraph.addVertex(adjList.get(n));
//		if (adjList.get(n).getSize() != 0) {
//			
//			for (int j = 0; j < adjList.get(j).getSize(); j++) {
//				Vertex a = adjList.get(j);
//				tGraph.addEdge(adjList.get(j), j);
//			}
//		}
//	}
//	
//	for (int v = 0; v < n; v++) {
//		Iterator<Integer> i = SCClist[v].iterator();
//		while(i.hasNext()) {
//			tGraph.SCClist[i.next()].add(v);
//		}
//
//	}
//
//	return tGraph;
//}


