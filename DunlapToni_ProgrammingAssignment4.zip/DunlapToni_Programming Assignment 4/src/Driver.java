/*
 * @author: Toni Dunlap
 * Date: 10/27/2018
 * Assignment: Project 4
 * Note: Previous code I was attempting for the assignment may be commented out. I've also written comments for the correct code also. 
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Creates my lists of planes, those that have landed, and their landing times
		//I also create a priority queue to hold the planes
		MinPriorityQueue pQueue = new MinPriorityQueue();
		ArrayList<Airplanes> planes = new ArrayList<>();
		ArrayList<Airplanes> landedPlanes = new ArrayList<>();
		ArrayList<Integer> lTimes = new ArrayList<>();

		//Used to output our final result to a text file
		PrintWriter dataOutput = null;

		//initializing variables that keep track of the current time, number of runways, and items dequeued 
		int currentTime, numRunways, dequeued;
		numRunways = 0;

		//used to receive text file input
		Scanner inputStream = null;

		//Checking to make sure the text file is properly read
		try
		{
			inputStream = new Scanner(new File(args[0]));
			numRunways = inputStream.nextInt();

			//fills the queue with planes
			while(inputStream.hasNext())
			{

				planes.add(new Airplanes(inputStream.next(), inputStream.nextInt(), inputStream.nextInt()));
			}
			inputStream.close();
		}
		catch(FileNotFoundException e)
		{
			System.out.println(e.getMessage());
			System.exit(0);
		}


		currentTime = 1; //starts the clock

		//MinPriorityQueue.readInFile(planes, new File(args[0]));
		dequeued = planes.size();

		while (dequeued > 0) {
			for (int i =0; i < planes.size(); i++) {
				if (planes.get(i).getArrivalTime() == currentTime) {		
					pQueue.heapInsert(planes.get(i));
					//if the plane is supposed to be landing at the current time, put it on the heap
				}

			}

			
				for (int i = 0; i < numRunways; i++) {
					if (pQueue.getSize() > 0) {
					//lands planes according to priorities and times and tracks the times the planes land
					landedPlanes.add(pQueue.extractMin());
					lTimes.add(currentTime);
					dequeued--;
				}

			}
			
			currentTime++; //moves time forward
		}
			//checks to make sure we can properly output the information we are tracking into a text file
			try {
				dataOutput = new PrintWriter(new File(args[1]));

				for (int i = 0; i < landedPlanes.size(); i++) {
					dataOutput.write(landedPlanes.get(i).getID() +"\t" + landedPlanes.get(i).getArrivalTime() + "\t" + landedPlanes.get(i).getLandingPriority() + "\t" + lTimes.get(i));
					dataOutput.write("\n"); 
				}

				dataOutput.flush();
				dataOutput.close();
			}
			catch (FileNotFoundException e) {
				System.out.println(e.getMessage());
				System.exit(0);
			}

		}
	}

