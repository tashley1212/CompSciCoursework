//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.util.ArrayList;
//import java.util.Scanner;

//import net.datastructures.LinkedQueue;

/*
 * @author: Toni Dunlap
 * Date: 10/27/2018
 * Assignment: Project 4
 * Note: Previous code I was attempting for the assignment may be commented out. I've also written comments for the correct code also. 
 */
public class MinPriorityQueue {

	private ArrayList<Airplanes> pHeap; //implementing my own priority heap using an array list filled with Airplanes
	private int heapSize; //tracking the arraylist size
	
	
	public MinPriorityQueue() { //constructor
		
	pHeap = new ArrayList<Airplanes>();
	pHeap.add(null); //sets first element of heap to null so that the heap index begins at 1
	heapSize = 0; //Initializing size to 0
	}

	//getter for heap size
		public int getSize() {
			return heapSize;
		}
		
	//this method is responsible for checking plane arrivals and priorities
	private int check(Airplanes first, Airplanes second) {
		int lPriority = first.getLandingPriority(); 
		int rPriority = second.getLandingPriority();
		
		int lArrival = first.getArrivalTime();
		int rArrival = second.getArrivalTime();
		
		if(lPriority > rPriority) {
			return 1;
		}
		else if(lPriority < rPriority) {
			return -1;
		}
		else if(lArrival > rArrival) {
			return 1;
		}
		else if(lArrival < rArrival) {
			return -1;
		}
		else {
			return 0;
		}
	}
//	public static void readInFile(ArrayList<Airplanes> planes, String file)
//	{
//		Scanner inputStream = null;
//		try
//		{
//			inputStream = new Scanner(new File(file));
//		}
//		catch(FileNotFoundException e)
//		{
//			System.out.println("Cannot open file: " + file);
//			System.exit(0);
//		}
//
//		numRunways = inputStream.nextInt();
//
//		//fills the queue with planes
//		while(inputStream.hasNext())
//		{
//			
//			planes.add(new Airplanes(inputStream.next(), inputStream.nextInt(), inputStream.nextInt()));
//		}
//	}
	
	//this method orders the heap to be a min heap, such that the parent of the "tree" is the smallest element
	public void minHeapify(int i) {
		
		//i = i -1; 
		int l = (i*2);
		int r = (i*2) + 1;
		
		int smallest = 0; 
		
		//the below statements call on the check method to verify arrival times and priorities to determine
		// whether the plane stored on the left or right should be moved up in the line to land
		if (l <= heapSize && check(pHeap.get(l), pHeap.get(i)) < 0) {
			smallest = l;
		}
		else {
			smallest = i;
		}
		
		if (r <= heapSize && check(pHeap.get(r), pHeap.get(smallest)) < 0) {
			smallest = r;
		}
		
		
		if (smallest !=i) {
			Airplanes temp = pHeap.get(i);
			pHeap.set(i, pHeap.get(smallest));
			pHeap.set(smallest, temp);
			minHeapify(smallest);
		}
	}
	
	//this method, as long as we have items on the heap, will return the smallest item on the tree
	public Airplanes minHeap() {
		if (heapSize > 0) {
			return pHeap.get(1);
		}
		else {
			return null;
		}
	}
//		Airplanes next = incoming.get(i);
//		int currentPriority = next.landingPriority;
//		int currentArrival = next.arrivalTime;
//		
//		int l = (2*i) % incoming.size() - 1;
//		Airplanes lPrioritylane = incoming.get(l);
//		
//		int lPriority = lPrioritylane.landingPriority;
//		int lArrival = lPrioritylane.arrivalTime;
//		
//		int r = (2*i + 1) % incoming.size() - 1;
//		Airplanes rPrioritylane = incoming.get(r);
//		int rPriority = rPrioritylane.landingPriority;
//		int rArrival = rPrioritylane.arrivalTime;
//		
//		Airplanes smallest;
//		int smallestIndex = (Integer) null;
//		
//		if(l <= incoming.size() && lPriority < currentPriority) {
//			smallest = lPrioritylane;
//			smallestIndex = l;
//		
//		
//		if (l <= incoming.size() && lArrival < currentArrival) {
//			smallest = lPrioritylane;
//			smallestIndex = l;
//		}
//		
//		else {
//			smallest = next;
//			smallestIndex = i;
//		}
//		}
//	
//	else {
//		smallest = next;
//		smallestIndex = i;
//	}
//	
//	if (r <= incoming.size() && rPriority < smallest.landingPriority)
//{
//	smallest = rPrioritylane;
//	smallestIndex = r;
//}
//	if(smallest.equals(next)) {
//		swap(incoming, i, smallestIndex);
//		minHeapify(incoming, smallestIndex);
//	}
//	}
	
	//this is what allows the planes to land and removes it from the list of planes waiting to land
	public Airplanes extractMin() {
		if (heapSize < 1) {
			System.out.println("HEAP UNDERFLOW");
			return null;
		}
		Airplanes minimum = pHeap.get(1);
		pHeap.set(1, pHeap.get(heapSize));
		pHeap.remove(heapSize);
		heapSize--;
		minHeapify(1);
		return minimum;		
	}
	
	//this method adds planes, as they come in, to the heap
	public void heapInsert (Airplanes plane) {
		pHeap.add(plane);
		heapSize++; //the size of the heap expands
		
		heapDecreaseKey(heapSize, plane);
	}
	
	
//	public static void swap(ArrayList<Airplanes> planeSwap, int incoming, int swapVar) {
//		Airplanes temp = planeSwap.get(incoming);
//		Airplanes swap = planeSwap.get(swapVar);
//		Airplanes swapPlane = temp;
//		
//		planeSwap.add(incoming, temp);
//		planeSwap.add(swapVar, swap);
//	}
//	
//	public void buildMaxHeap(ArrayList<Airplanes> A) {
//		heapSize = A.size();
//		
//		for (int i = A.size(); i>= 1; i--) {
//		minHeapify(A, i);
//		
//		}
//	}
//	
//	public void heapsort (ArrayList<Airplanes> plane){
//		buildMaxHeap(plane);
//		
//		for (int i = plane.size(); i >= 2; i--) {
//			swap(plane, 1, i);
//			heapSize = heapSize - 1;
//			
//			minHeapify(plane, 1);
//		}
//	}
	
	
	
	private void heapDecreaseKey(int i, Airplanes plane) {
	
		int parent = i/2;
		
		while (i > 1 && check(pHeap.get(parent), pHeap.get(i)) > 0) {
			
			Airplanes newKey = pHeap.get(i);
			
			pHeap.set(i, pHeap.get(parent));
			
			pHeap.set(parent, newKey);
			
			i = parent;
			
			parent = i/2;
			
		}
			
		}
	
//		int parent = i/2;
//		
//		while (i > 1 && minHeapify(pHeap.get(r), pHeap.get(smallest)) < 0) {
//		int keyPriority = key.landingPriority;
//		int keyArrival = key.arrivalTime;
//		
//		if(keyPriority < plane.get(i).landingPriority) {
//			System.out.println("New key is smaller than current key");
//			
//		}
//		plane.add(i, key);
//		
//		while (i > 1 && plane.get(i).landingPriority < keyPriority){
//			swap(plane, i, keyIndex);
//			plane.add(i, key);
//		}
	

//	//unsure about this
//	public void heapInsert(Airplanes p) {
//		pHeap.add(p);
//		heapSize++;
//		heapIncreaseKey(heapSize, p);
//	}
	
//	public static String toString(ArrayList<Airplanes> planes) {
//		LinkedQueue<Airplanes> planeQueue = new LinkedQueue<> ();
//		
//		for (int i = 0; i< planes.size() - 1; i++) {
//			planeQueue.enqueue(planes.get(i));
//		}
//		LinkedQueue<Airplanes> copy = planeQueue;
//		
//		StringBuilder sb = new StringBuilder();
//		
//		for (int i = 0; i<= planes.size() -1; i++) {
//			Airplanes current = copy.dequeue();
//			
//			sb.append(current.getID() + " " + current.getArrivalTime() + " " + current.getLandingPriority() + " ");
//			sb.append("\r");
//		}
//		
//		return sb.toString();
//	}
//	
	
}



