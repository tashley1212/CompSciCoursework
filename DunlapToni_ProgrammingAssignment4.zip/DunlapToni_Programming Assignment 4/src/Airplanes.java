/*
 * @author: Toni Dunlap
 * Date: 10/27/2018
 * Assignment: Project 4
 * Note: Previous code I was attempting for the assignment may be commented out. I've also written comments for the correct code also. 
 */


//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.util.ArrayList;
//import java.util.LinkedList;
//import java.util.Scanner;
//

public class Airplanes {

	//public static int timer; 
	private int arrivalTime;
	private int landingPriority;
	private String flightID;
//
//	static Queue<Airplanes> InfoHolder = new LinkedList<>();
//	static Queue<Airplanes> copy = new Queue<Airplanes>();
//	
	//receiving information from the provided text files and storing them under these variable names
	public Airplanes(String flightID, int arrivalTime, int landingPriority) {

		//timer = 0;
		this.flightID = flightID;
		this.arrivalTime = arrivalTime;
		this.landingPriority = landingPriority;
	}

	//getters for the data
	public String getID() {
		return flightID;
	}
	
	public int getArrivalTime() {
		return arrivalTime;
	}
	public int getLandingPriority() {
		return landingPriority;
	}
	
	
	
	
	
//	public static Queue readFile(String file) {
//
//		Scanner sc = null;
//		try {
//			sc = new Scanner (new FileInputStream(file));
//		}
//
//		catch (FileNotFoundException e) {
//			System.out.println("Having issues opening this file: "+file);
//			System.exit(0);
//		}
//
//		int numOfRunways = sc.nextInt();
//
//		while (sc.hasNext()) {
//			Airplanes plane = new Airplanes(sc.next(), sc.nextInt(), sc.nextInt());
//			InfoHolder.add(plane);
//			InfoHolder.
//		}
//		InfoHolder = copy;
//		return copy;
//	}
//
//	public static String toString(Queue<Airplanes> q) {
//		StringBuilder sb = new StringBuilder();
//		
//		for (int i = 0; i < copy.size(); i++) {
//			Airplanes info = copy.poll();
//			sb.append("Aircraft "+info.flightID +"arrived at "+info.arrivalTime +"with a landing priority of " +info.landingPriority +" and landed at time "+timer);
//			sb.append("/r");		
//		}
//		return sb.toString();
//		
//	}


}
