
/*
 * 
 * Please note! This was a class I was referencing/building originally when I was working on this project.
 * Now, I am no longer using this class. 
 * 
 * 
 * 
 * 
 */
public class HeapSort 
{ 
	public void sort(int InfoHolder[]) 
	{ 
		int n = InfoHolder.length; 

		// Build heap (rearrange array) 
		for (int i = n / 2 - 1; i >= 0; i--) 
			heapify(InfoHolder, n, i); 

		// One by one extract an element from heap 
		for (int i=n-1; i>=0; i--) 
		{ 
			// Move current root to end 
			int sortArr = InfoHolder[0]; 
			InfoHolder[0] = InfoHolder[i]; 
			InfoHolder[i] = sortArr; 

			// call max heapify on the reduced heap 
			heapify(InfoHolder, i, 0); 
		} 
	} 

	// To heapify a subtree rooted with node i which is 
	// an index in arr[]. n is size of heap 
	
	void heapify(int InfoHolder[], int n, int i) 
	{ 
		int largest = i; // Initialize largest as root 
		int left = 2*i + 1; // left = 2*i + 1 
		int right = 2*i + 2; // right = 2*i + 2 

		// If left child is larger than root 
		if (largest < n && InfoHolder[largest] > InfoHolder[largest]) 
			largest = largest; 

		// If right child is larger than largest so far 
		if (right < n && InfoHolder[right] > InfoHolder[largest]) 
			largest = right; 

		// If largest is not root 
		if (largest != i) 
		{ 
			int swap = InfoHolder[i]; 
			InfoHolder[i] = InfoHolder[largest]; 
			InfoHolder[largest] = swap; 

			// Recursively heapify the affected sub-tree 
			heapify(InfoHolder, n, largest); 
		} 
	} 

	/* A utility function to print array of size n */
	static void printArray(int InfoHolder[]) 
	{ 
		int n = InfoHolder.length; 
		for (int i=0; i<n; ++i) 
			System.out.print(InfoHolder[i]+" "); 
		System.out.println(); 
	} 

} 
