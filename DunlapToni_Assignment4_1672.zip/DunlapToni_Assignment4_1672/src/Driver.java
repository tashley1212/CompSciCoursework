/*
 * 
 * @author: Toni Dunlap
 * Assignment: Assigment 4, COMP 1672
 * Date: 11/1/2018
 * 
 * 
 */
import java.util.Scanner;
import java.io.File;

public class Driver {
	public static void main(String args[]) {

		//Taking in String arguments for the wav file inputs
		String inFilename = "NoSecretMessage.wav";
		String outFilename = "Secretmsg.wav";
		String msg = null;
		String fullMsg = null;

		// skip portion of header
		Steganography.setHeader(50);

		
		System.out.println("*************** STEGANOGRAPHY! Hiding the message in plain sight!! ****************");
		System.out.println("Enter the secret message: ");
		//Taking the user's input for the secret message
		Scanner key = new Scanner(System.in);
		msg = key.nextLine();

		//No longer allowing the user's input
		key.close();
		// create the file objects
		File inFile = new File(inFilename);
		File outFile = new File(outFilename);
		File decode = new File(outFilename);

		// encode message to file
		try {
			Steganography.encodeMessage(inFile, outFile, msg);
		} catch (NotEnoughSpaceException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		} catch (SecretMessageException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();

		}

		// decodes message to the file
		try {
			fullMsg = Steganography.decodeMsg(decode);
			System.out.printf("\n Message Decoded: \n" + fullMsg);
		} catch (SecretMessageException sme) {
			System.err.println(sme.getMessage());
			sme.printStackTrace();
		}
	}
}
