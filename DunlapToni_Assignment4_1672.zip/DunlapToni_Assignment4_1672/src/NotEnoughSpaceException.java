/*
 * 
 * @author: Toni Dunlap
 * Assignment: Assigment 4, COMP 1672
 * Date: 11/1/2018
 * 
 * 
 */
public class NotEnoughSpaceException extends Exception {
	public NotEnoughSpaceException() {
		super("Not Enough Space Exception");
	}

	public NotEnoughSpaceException(String msg) {
		super(msg);
	}

}
