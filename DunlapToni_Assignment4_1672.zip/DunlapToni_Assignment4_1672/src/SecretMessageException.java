/*
 * 
 * @author: Toni Dunlap
 * Assignment: Assigment 4, COMP 1672
 * Date: 11/1/2018
 * 
 * 
 */
 
// This exception is thrown when the input file doesn't exist or there is no secret msg

public class SecretMessageException extends Exception {
	public SecretMessageException() {
		super("Secret Message Exception");
	}

	public SecretMessageException(String msg) {
		super(msg);
	}

}
