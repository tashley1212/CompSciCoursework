/*
 * 
 * @author: Toni Dunlap
 * Assignment: Assigment 4, COMP 1672
 * Date: 11/1/2018
 * 
 * 
 */
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.File;
import java.io.IOException;
//import java.io.InputStream;
import java.io.FileNotFoundException;

public class Steganography {
	private static int headerBytes = 0;

	// Set the header value since different file types have different sizes for
	// their headers
	public static void setHeader(int header) {
		headerBytes = header;
	}
	
	public static void encodeMessage(File inputFile, File outputFile, String message)
			throws SecretMessageException, NotEnoughSpaceException {
		RandomAccessFile outputStream = null;
		int length = message.length();
		// gets the path of the file to read from and the destination file
		Path ipath = inputFile.toPath();
		Path opath = outputFile.toPath();

		try {
			Files.copy(ipath, opath, StandardCopyOption.REPLACE_EXISTING);

			outputStream = new RandomAccessFile(outputFile.getPath(), "rw");
			// gets the location to store each character
			int[] arr = getDataLocations(headerBytes, (int) (outputFile.length() - 1), length);

			outputStream.seek(headerBytes);
			outputStream.writeInt(length); // write the length of the message into the file

			// adds one byte to the message so the last position can be read and have a zero
			// written after it
			for (int i = 0; i < length; i++) {
				outputStream.seek(arr[i]);
				outputStream.writeChar(message.charAt(i));
				outputStream.writeInt(arr[i + 1]);
			}

			outputStream.close();
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
			ioe.printStackTrace();
			throw new SecretMessageException("Cannot read the message");
		}
	}

	public static String decodeMsg(File inputFile) throws SecretMessageException {
		RandomAccessFile inputStream = null;
		char[] msg = null;
		String fullMsg = null;
		int length = 0;

		try {
			// read file
			inputStream = new RandomAccessFile(inputFile.getPath(), "r");
			inputStream.seek(headerBytes);
			length = inputStream.readInt();

			msg = new char[length];

			for (int i = 0; i < length; i++) {
				msg[i] = inputStream.readChar();
				inputStream.seek(inputStream.readInt());
			}
			fullMsg = new String(msg);

			inputStream.close();
		} catch (FileNotFoundException test) {
			System.err.println("Error finding the file: " + inputFile.getName());
			test.printStackTrace();
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
			ioe.printStackTrace();
			throw new SecretMessageException("Can't read msg.");
		}

		return fullMsg;
	}
	
	public static int[] getDataLocations(int start, int stop, int numLocations) throws NotEnoughSpaceException {

		int[] a = new int[numLocations + 1];
		int next = 0;

		int offset = (int) Math.abs((start - stop) / (numLocations));
		// 4 bytes are needed to store the length of the message
		int spaceNecessary = start + 4 + 2 * numLocations + 8 * numLocations + offset;

		if (spaceNecessary > (stop - start)) {
			throw new NotEnoughSpaceException("The file is too small to fit message! " + spaceNecessary
					+ " bytes needed, only " + (stop - start) + " bytes available");
		}

		for (int i = 0; i < a.length; i++) {
			a[i] = start + 4;
		}

		for (int i = 1; i < a.length; i++) {
			if (i != a.length - 1) {
				next += offset;
				a[i] += next;
			} else {
				a[i] = 0;
			}
		}
		return a;
	}
	
	
}
