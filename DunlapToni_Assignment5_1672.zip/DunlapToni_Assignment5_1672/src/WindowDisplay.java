/*
 * @author: Toni Dunlap
 * Assigment: Assignment 5, COMP 1672
 * Date: 11/14/2018
 */

import java.awt.Color;
import java.util.ArrayList;
import edu.princeton.cs.introcs.Draw;
//import edu.princeton.cs.introcs.*;
import edu.princeton.cs.introcs.DrawListener;

public class WindowDisplay implements DrawListener {

	private ArrayList<Window> windows;	
	private ArrayList<Window> windowCopy;
	private double[] xCordcopy = new double [4];
	private double[] yCordcopy = new double [4];
	Draw object;
	private int i = 0;
	
	public WindowDisplay(int xScale, int yScale) {
		//creating our canvas and activating our listener
		object = new Draw();
		object.addListener(this);
		windows = new ArrayList<Window>();
		windowCopy = new ArrayList<Window>();
		object.setCanvasSize(600, 600);
		object.setXscale(0, xScale);
		object.setYscale(yScale, 0);
	}

	public void addWindow(Window w) {
		//adding windows to array list
		windows.add(w);
		windowCopy.add(w);
	}
	


	public void draw() {
		for (Window w : windows) { // for each window in the ArrayList, draw the window
			//System.out.println("Hello");
			w.display();
		}
	}

	private void windowClicked(double mx, double my) {
		//adjusts the ordering of which window is on top	
		for (int i = windows.size()-1; i >= 0; i--){ //decrementing down the left of windows on top of each other
			if (windows.get(i).windowLocation(mx, my)) {
				windows.add(windows.get(i));
				windows.remove(i);
				break;
			}
		}
	}
	@Override
	public void mousePressed(double x, double y) {
		// TODO Auto-generated method stub
		
		windowClicked(x,y);
		draw();
	}

	@Override
	public void mouseDragged(double x, double y) {
		// TODO Auto-generated method stub
		//need feedback on this method
		for (int i = windows.size()-1; i >= 0; i--){ //decrementing might be easier to check the window being clicked, because
			//it might be easier to see the window closest to the top to drag it
			if (windows.get(i).windowLocation(x, y)) {
				//the below process in green didn't work, but it's what I tried first
				
				//windows.add(windows.get(i));
//				windows.get(i).xCord = x;
//				windows.get(i).yCord = y;
//				break;
				//windows.remove(i);
				windows.get(i).xCord = x;
				windows.get(i).yCord = y;
				//windows.get(i).display(); didn't work
				object.clear();
				draw();
				break;
			}
			//windows.remove(i);
		}
	}

	@Override
	public void mouseReleased(double x, double y) {
		// TODO Auto-generated method stub
		//need feedback on this method
		
	}

	@Override
	public void keyTyped(char c) {
		// TODO Auto-generated method stub
//		int qCode = 81;
//		int rCode = 82;
		if (c == 'r'){ //82 indiciated r was pressed
			reset();
		}
		if (c == 'q') {// 81 indicates q was pressed
			System.exit(0);
		}
	}
	
	public void reset() {
		//clears the display and resets back to original layout
		windows.clear();
		for (int i =0; i < windowCopy.size(); i++) {
			windowCopy.get(i).xCord = xCordcopy[i];
			windowCopy.get(i).yCord = yCordcopy[i];
			windows.add(windowCopy.get(i));
			
		}
		object.clear();
		draw();
		
	}


	
	@Override
	public void keyPressed(int keycode) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(int keycode) {
		// TODO Auto-generated method stub

	}
	
	public class Window {

		private double xCord;
		private double yCord;
		private double width;
		private double height;
		private Color color;
		
		//creating windows of different sizes and colors
		public Window (double xCord, double yCord, double width, double height, Color color) {
			this.xCord = xCord;
			this.yCord = yCord;
			this.width = width;
			this.height = height;
			this.color = color;
			
			//storing all the x and y coordinate information of the original layout
			//to be used later in the reset method
			while (i < 4) {
			xCordcopy[i] = xCord;
			yCordcopy[i] = yCord;
			break;
		}
			i++;
		}
		//responsible for displaying the windows on the canvas
		public void display() {
			//Draw.setPenColor();
			object.setPenColor(color);
			//object.setPenRadius(1);
			object.filledRectangle(xCord, yCord, width/2, height/2);
			//object.show();
		}
		
		public boolean windowLocation(double xCord, double yCord) {
			//method to see if the mouse is clicking inside a window
			if(xCord < this.xCord + width/2 && xCord > this.xCord - width/2 && yCord < this.yCord + height/2 && yCord > this.yCord - height/2)
			{
				return true;
			}
			else {
				return false;
			}
		}
	}
}
