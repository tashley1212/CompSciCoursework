/*
 * @author: Toni Dunlap
 * Assigment: Assignment 5, COMP 1672
 * Date: 11/14/2018
 */

//import WindowDisplay.Window;

import edu.princeton.cs.introcs.Draw;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WindowDisplay w = new WindowDisplay(200, 200); 
		
		WindowDisplay.Window w1 = w.new Window(50, 50, 60, 80, Draw.BLUE);
		w.addWindow(w1);   
		WindowDisplay.Window w2 = w.new Window(100, 130, 80, 80, Draw.RED );
		w.addWindow(w2);
		WindowDisplay.Window w3 = w.new Window(80, 80, 60, 80, Draw.GREEN ); 
		w.addWindow(w3); 
		WindowDisplay.Window w4 = w.new Window(120, 60, 100, 80, Draw.BLACK );
		w.addWindow(w4); 
		w.draw();	
		}

}
