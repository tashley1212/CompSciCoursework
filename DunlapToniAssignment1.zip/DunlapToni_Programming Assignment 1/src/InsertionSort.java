/*
 * @Toni Dunlap
 * Date: 9/15/2018
 * Assignment 01 - Insertion Sort
 */
import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import net.datastructures.ExpandableArrayList;
import net.datastructures.List;


public class InsertionSort {


	private File file; //helps open our text file
	private ArrayList<String> listOfWords; //place to hold this list of words retrieved from the dictionary.txt

	private char[] letterEval;
	private boolean orderTest; //to check whether one value is bigger than the other during the sorting process

	public InsertionSort() {

		//file = new File("istest1.txt"); //importing the list of words
		listOfWords = new ArrayList<String>(); //initializing a ArrayList that takes 
		// in variables of type string

		Scanner sc = null; //what reads out text file
		try {

			sc = new Scanner (new File("istest1.txt"));
		}
		catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
			//notify if you can't locate the text file
		}
		while (sc.hasNext()) {
			String word = sc.next();
			listOfWords.add(listOfWords.size(),word);
		}

	}


	public void startSort() {

		for (int i = 1; i < listOfWords.size(); i++) {
			String compareWord = listOfWords.get(i);
			int j = i-1; 
					
				while (j >= 0 && listOfWords.get(j).compareTo(compareWord) > 0) {

					
					listOfWords.set(j+1, listOfWords.get(j));
					j = j-1;
				}
					listOfWords.set(j+1,compareWord);
				}
			
		
		System.out.println(listOfWords.toString());
	}
}
