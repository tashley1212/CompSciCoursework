import java.io.File;

/*
 * @Toni Dunlap
 * Date: 9/15/2018
 * Assignment 01 - Insertion Sort
 */
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File(args[0]);
		InsertionSort sort1 = new InsertionSort();
		System.out.println("Below is the alphabetized list: \n");
		sort1.startSort();
		
		
	}

}
