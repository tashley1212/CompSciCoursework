package net.datastructures;

public interface List<E> 
{
	public void add(E v, int i);
	public E get(int i);
	public E remove(int i);
	public E set(E v, int i);
	public int size();
	public boolean isEmpty();
	void expandArray();
}
