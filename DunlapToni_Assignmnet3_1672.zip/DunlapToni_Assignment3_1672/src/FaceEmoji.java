/*
 * @author: Toni Dunlap
 * date: 10/21/2018
 * Assignment 3, COMP 1672
 * 
 * This file builds the base/foundation for the emoji faces that will be displayed. It gives every emoji eyes and a wink.
 */
import edu.princeton.cs.introcs.StdDraw;

public abstract class FaceEmoji extends Emoji{
	//Initializing instance variable
	private boolean isWinking = true;
	
	//Constructor
	public FaceEmoji (int xPos, int yPos, int size) {
		super (xPos, yPos, size);
	}
	
	//Draw method
	public void draw() {
		//Face Color
		StdDraw.setPenColor(StdDraw.YELLOW);
		StdDraw.filledCircle(getXPos(), getYPos(), getSize());
		//Eyes
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.filledCircle(getXPos() - 30, getYPos() + 10, getSize() - 70);
		//StdDraw.filledCircle(x + 20, y + 10, size - 40);

		if(!isWinking) {
			StdDraw.filledCircle(getXPos() + 30, getYPos() + 10, getSize() - 70);
		}
		else {
			StdDraw.line(getXPos() + 30, getYPos() + 10,  getXPos() + 40, getYPos() + 10);
		}
	}

	
	public void wink() {
		isWinking = !isWinking;
	}
	
	@Override
	public void animate() {
		wink();
	}
}