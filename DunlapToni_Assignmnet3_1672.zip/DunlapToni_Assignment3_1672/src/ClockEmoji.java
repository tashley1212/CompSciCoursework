/*
 * @author: Toni Dunlap
 * date: 10/21/2018
 * Assignment 3, COMP 1672
 * 
 * This file implements the hour and minute hand for the clock
 */
import edu.princeton.cs.introcs.StdDraw;
public class ClockEmoji extends Emoji{

	private int hour, minute;
	public ClockEmoji(int xPos, int yPos, int size, int newHour, int newMinute) {
		super(xPos, yPos, size);	 
		this.hour = newHour;
		this.minute = newMinute;
		
	}
	
	public void draw() {
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.circle(getXPos(), getYPos(), getSize());
		double x1 = getXPos() + 0.95 * getSize() * Math.sin((hour % 12) * (Math.PI/ 6));
		double y1 = getYPos() + 0.95 * getSize() * Math.cos((hour % 12) * (Math.PI/ 6));
		double x2 = getXPos() + 0.95 * getSize() * Math.sin((minute % 12) * (Math.PI/ 6));
		double y2 = getYPos() + 0.95 * getSize() * Math.cos((minute % 12) * (Math.PI/ 6));
		StdDraw.line(getXPos(), getYPos(),  x1,  y1);
		StdDraw.line(getXPos(), getYPos(),  x2,  y2);
	}
	
	public void tick() {
		//++hour;
		++minute;
		if (minute >= 12) {
			++hour;
			minute = 0;
		}
		draw();
	}
	
	@Override
	public void animate() {
		tick();
	}
	
}
