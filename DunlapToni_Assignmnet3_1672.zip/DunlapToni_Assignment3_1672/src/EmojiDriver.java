/*
 * @author: Toni Dunlap
 * date: 10/21/2018
 * Assignment 3, COMP 1672
 */
import edu.princeton.cs.introcs.*;

import java.awt.Canvas;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class EmojiDriver {
	public static final int CANVAS_SIZE = 800;
	public static void main(String[] args)
	{
		//Set the canvas
		StdDraw.setCanvasSize(CANVAS_SIZE, CANVAS_SIZE);
		StdDraw.setXscale(0, CANVAS_SIZE);
		StdDraw.setYscale(0, CANVAS_SIZE);
		StdDraw.setPenColor(StdDraw.BLACK);
		//Locates file
		Scanner s = null;
		try {
			s = new Scanner(new FileInputStream("emoji1.txt"));
		}
		
		catch(FileNotFoundException e) {
			System.out.println("File not found");
			System.exit(0);
		}
		//Creates the array to store information we're reading in from the text file
		int rows = s.nextInt();
		int columns = s.nextInt();
		Emoji[][] emoji = new Emoji[rows][columns];
		String value = s.nextLine();
		
		
		for (int i = 0; i < emoji.length; i++) {
			for(int j = 0; j < emoji[i].length; j++) {
				String type = s.next();
				int x = (i * 200) + 100;
				int y = (j * 200) + 100;
				int size = CANVAS_SIZE/10;
				
				if (type.equalsIgnoreCase("smile")) {
					emoji[i][j] = new SmileyFaceEmoji(x,y,size);
				}
				else if (type.equalsIgnoreCase("frown")) {
					emoji[i][j] = new FrowningFaceEmoji(x,y,size);
				}
				else if (type.equalsIgnoreCase("clock")) {
					int hours = s.nextInt();
					int minute = s.nextInt();
					emoji[i][j] = new ClockEmoji(x,y,size, hours, minute);
				}
				else {
					System.out.println("Error reading at" + i + ", " + j + " read '" + type + "'");
				}
			}
		}
		s.close();
	//Animation
		StdDraw.enableDoubleBuffering();
		while(true) {
			for(int i = 0; i < emoji.length; i++) {
				for(int j = 0; j < emoji[i].length; j++) {
					//emoji[i][j].animate();
					if(emoji[i][j] instanceof ClockEmoji) {
						ClockEmoji c = (ClockEmoji)emoji[i][j];
						c.tick();
					}
					if(emoji[i][j] instanceof FaceEmoji) {
						FaceEmoji f = (FaceEmoji)emoji[i][j];
						f.wink();
					}
					
				}
							
			}
			StdDraw.clear();
			for(int i = 0; i < emoji.length; i++) {
				for(int j = 0; j < emoji[i].length; j++) {
					emoji[i][j].draw();
				}
			}
			StdDraw.show();	
			StdDraw.pause(500);
		}
		
	}
}

