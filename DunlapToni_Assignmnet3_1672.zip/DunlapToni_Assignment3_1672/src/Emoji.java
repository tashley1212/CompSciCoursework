/*
 * @author: Toni Dunlap
 * date: 10/21/2018
 * Assignment 3, COMP 1672
 * 
 * This file controls the animating and drawing of each of the emoji types. All files extend from this one.
 */
public abstract class Emoji {
	//any class with abstract methods must be abstract itself

	//Instance variable
	private double xPos, yPos, size;
	
	//Constructor
	public Emoji(int xPos, int yPos, int size) {
//		this.setxPos(xPos);
//		this.setyPos(yPos);
//		this.setSize(size);
		
		this.xPos = xPos;
		this.yPos = yPos;
		this.size = size;
	}
	
	//Public get methods for int variables
	public double getXPos() {
		return getxPos();
	}
	public double getYPos() {
		return getyPos();
	}
	public double getSize() {
		return size;
	}
	
	//Draw method
	public abstract void draw();
	
	public abstract void animate();

	public double getxPos() {
		return xPos;
	}

	public void setxPos(int xPos) {
		this.xPos = xPos;
	}

	public double getyPos() {
		return yPos;
	}

	public void setyPos(int yPos) {
		this.yPos = yPos;
	}

	public void setSize(int size) {
		this.size = size;
	}


	
}
