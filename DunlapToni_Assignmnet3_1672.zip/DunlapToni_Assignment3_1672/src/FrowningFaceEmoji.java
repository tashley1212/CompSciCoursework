/*
 * @author: Toni Dunlap
 * date: 10/21/2018
 * Assignment 3, COMP 1672
 * 
 * This files creates the frown for the frowning emojis 
 */

import edu.princeton.cs.introcs.StdDraw;
public class FrowningFaceEmoji extends FaceEmoji{

	public FrowningFaceEmoji(int xPos, int yPos, int size) {
		super(xPos, yPos, size);
		//this.setxPos(xPos);
		//this.setyPos(yPos);
		//this.setSize(size);
	}

	//Draw method
	public void draw() {
		super.draw();
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.setPenRadius(0.012);
		StdDraw.circle(getXPos(),getYPos(),getSize());
		StdDraw.setPenColor(StdDraw.BLACK);
		//StdDraw.circle(getxPos(), getyPos(),getSize());
		StdDraw.arc(getxPos(), getyPos() - 100, getSize() - 10, 50.0, 130.0);

	}
}
