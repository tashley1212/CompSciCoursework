/*
 * @author: Toni Dunlap
 * date: 10/21/2018
 * Assignment 3, COMP 1672
 * 
 * This file implements the upward arc that creates the smile on certain emojis
 */

import edu.princeton.cs.introcs.StdDraw;
public class SmileyFaceEmoji extends FaceEmoji{

	public SmileyFaceEmoji(int xPos, int yPos, int size) {
		super(xPos,yPos,size);
	}
	
	//Draw method
	public void draw() {
		super.draw();
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.setPenRadius(0.012);
		StdDraw.circle(getXPos(),getYPos(),getSize());
		StdDraw.arc(getXPos(), getYPos() + 5, getSize() - 10, 220.0, 320.0);
		
	}
}
