
/*
 * Assignment 2
 * By: Toni Dunlap
 * Date: 9/24/2018
 * Collaborated with others in class
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

//Driver Program to run the application
public class RunningTimesDriver {
	public static void main(String[] args)  {
		int iter; //variable for math calculations
				
		double iTime = 0; //time to complete insertion sort
		double insertAvg = 0; // average time for insertion sort
		double mTime = 0; //time to complete merge sort
		double mergeAvg = 0; // average time for merge sort
		
		ArrayList<String> original = new ArrayList<>();
		ArrayList<String> insertionSort = new ArrayList<>(); // where to sort the values using insertion sort
		ArrayList<String> mergeSort = new ArrayList<>(); // where to sort the values using merge  sort
		
		try {
			
			Scanner sc = null;
			sc = new Scanner(new File (args[0]));
			//utilizing command line for the file
			
			while (sc.hasNext()) {
				original.add(sc.next());
			}
			sc.close();
		}
		
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		for (int n = 2; n <= 8192; n = n* 2) {
			iter = Math.max(4, 8192/n);
			CpuTimer timer1 = new CpuTimer();
			
			for (int i = 0; i < iter; i++) {
				insertionSort = RunningTimesTest.InsertionSort(original, n);
			}
			
			iTime = timer1.getElapsedCpuTime();
			insertAvg = iTime/iter;
		
		
		CpuTimer timer2 = new CpuTimer();
		
		for (int i = 0; i < iter; i++) {
			mergeSort = RunningTimesTest.MergeSort(original, n);
		}
		
		mTime = timer2.getElapsedCpuTime();
		mergeAvg = mTime/iter;
		
		if (RunningTimesTest.AlphaSorted(original) || !RunningTimesTest.AlphaSorted(mergeSort) || RunningTimesTest.checkHash(original, n) != RunningTimesTest.checkHash(mergeSort,n)) {
			
			System.out.println("There is an issue!");
		}
		
		System.out.println("Average times for n = " + n + ": Insertion Sort " + insertAvg + " sec., Merge Sort " + mergeAvg + " sec.");
		}
	}
}
		
		