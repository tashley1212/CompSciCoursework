/*
 * Assignment 2
 * By: Toni Dunlap
 * Date: 9/24/2018
 * Collaborated with others in class
 */
import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import net.datastructures.ExpandableArrayList;
import net.datastructures.List;

public class RunningTimesTest{	

	public static boolean AlphaSorted(ArrayList<String>original)
	{
		for(int i=0; i< original.size() - 1; i++) {
			if(original.get(i).compareTo(original.get(i+1)) > 0) {
				return false;
				}
		}
		//if each second element is smaller than the first element, array is not sorted
		return true;
	
	}

	 public static int checkHash(ArrayList<String> a, int n) {
		int hash = 0;
		for (int i = 0; i < n; i++)
			hash ^= a.get(i).hashCode();
		return hash;
	}
	 
	
	// Insertion Sort
	public static ArrayList<String> InsertionSort(ArrayList<String> arr, int n){
		ArrayList<String> original2 = new ArrayList<String>();
		for (int i = 0; i<= n; i++) {
			original2.add(original2.get(i));
		}
		
		for (int i = 1; i < original2.size(); i++) {
			String key = original2.get(i);
			int j = i - 1;
		
		
		while ( j>= 0 && original2.get(j).compareTo(key)> 0) {
			original2.set(j+1, original2.get(j));
			j = j-1;
		}
		original2.set(j+1, key);
	}
		return original2;
	}


	public static void merge(ArrayList<String> original, int p, int q, int r) {
		int n1 = q - p + 1;
		int n2 = r - q;
		
		String[] left = new String[n1];
		String[] right = new String [n2];
		
		for (int i=0; i < n1; i++) {
			left[i] = original.get(p + i);
		}
		
		for (int j = 0; j < n2; j++) {
			right[j] = original.get(q + j + 1);
		}
		int i = 0;
		int j = 0;
		int k = p;
		
		while (i < n1 && j < n2) {
			if (left[i].compareTo(right[j]) <=0 ) {
				original.set(k, left[i]);
				i++;
			}
			else {
				original.set(k, right[j]);
				j++;
			}
				k++;
		}
		
		while (i < n1) {
			original.set(k, left[i]);
			i++;
			k++;
		}
		
		while (j < n2) {
			original.set(k, right[j]);
			j++;
			k++;
		}
	}
	//Sort method for merge
	private static void MergeSortSetup(ArrayList<String> original, int p, int r)
	{
		if (p < r) {
			int q = p + (r-p)/2;
			MergeSortSetup(original, p, q);
			MergeSortSetup(original, q+1, r);
			merge(original, p, q, r);
		}
	}

	//Merge method of all array elements after divide and conquer
	public static ArrayList<String> MergeSort(ArrayList<String> original, int n)
	{   
		ArrayList<String> newArr = new ArrayList<String>();
		for (int i = 0; i <= n; i++) {
			newArr.add(newArr.get(i));
			}
		MergeSortSetup(newArr, 0, newArr.size() - 1);
		return newArr;
	}
}