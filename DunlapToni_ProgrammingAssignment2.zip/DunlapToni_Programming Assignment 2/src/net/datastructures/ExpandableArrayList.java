package net.datastructures;

/*
 * @author: Toni Dunlap
 * date: 4/18/18
 * assignment: Lab 07
 */
public class ExpandableArrayList<E> implements List<E>
{
	protected E[] array;
	protected int size;

	public ExpandableArrayList()
	{
		setArray((E[]) new Object[16]);
		size = 0;
	}

	public void expandArray()
	{
		//geometric 
		E[] temp = (E[]) new Object[2 * getArray().length];
		for(int i=0; i < getArray().length; i++)
		{
			temp[i] = getArray()[i];
		}

		setArray(temp);
	}

	public void add(E v, int index)
	{
		if(index < 0 || index > size)
		{
			throw new IndexOutOfBoundsException();
		}

		if(size == getArray().length)
		{
			expandArray();
		}

		for(int i =  size-1; i >= index; i--)
		{
			getArray()[i+1] = getArray()[i];
		}
		getArray()[index] = v;
		size++;
	}

	public E get(int index) 
	{
		if(index < 0 || index >= size)
		{
			throw new IndexOutOfBoundsException();
		}
		return getArray()[index];
	}

	public E remove(int index) 
	{
		if(index < 0 || index >= size)
		{
			throw new IndexOutOfBoundsException();
		}
		E value = getArray()[index];
		
		for(int i=index; i < size-1; i++)
		{
			getArray()[i] = getArray()[i+1];
		}
		
		getArray()[size-1] = null;
		size--;
		return value;
	}


	public E set(E v, int index) 
	{
		if(index < 0 || index >= size)
		{
			throw new IndexOutOfBoundsException();
		}

		E value = getArray()[index];
		getArray()[index] = v;
		return value;
	}


	public int size() 
	{
		return size;
	}

	public boolean isEmpty() 
	{
		return size == 0;
	}

	public String toString()
	{
		String result = "";
		for(int i=0; i < size; i++)
		{
			result += getArray()[i] + " ";
		}
		return result;
	}

	public E[] getArray() {
		return array;
	}

	public void setArray(E[] array) {
		this.array = array;
	}

}