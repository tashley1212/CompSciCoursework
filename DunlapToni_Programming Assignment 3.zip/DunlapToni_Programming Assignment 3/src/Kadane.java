import java.util.ArrayList;

public class Kadane {

	//making a circular ArrayList
	public static int maxCircularSum (ArrayList<Integer> unarr) {
		int n = unarr.size();
		
		int kadaneMax = kadane(unarr); //calls the kadane method below
		
		int maxWithCE = 0; // Initializing for max across entire circular array
		for (int i = 0; i < n; i++) {
			
			maxWithCE += unarr.get(i);
			unarr.set(i, -(unarr.get(i)));
		}
		
		maxWithCE = maxWithCE + kadane(unarr);
		
		//checking to see whether the max found via kadane is greater than the 
		//one found after continuing to add values to the kadane max 
		if (maxWithCE > kadaneMax) {
			return maxWithCE;
		}
		else {
			return kadaneMax;
		}		
	}
	
	 public static int kadane (ArrayList<Integer> unarr) 
	    { //code for the kadane method
		 
	        int n = unarr.size(); 
	        int currentMax = 0; //initializing variable for current max sum
	        int maxEnding = 0;  //initializing variable for end of max sum
	        for (int i = 0; i < n; i++) 
	        { //loop from 0 to the end of the array list 
	        	
	        	//below is the code that finds the max sum using Kadane's method
	            maxEnding = maxEnding + unarr.get(i); 
	            if (maxEnding < 0) 
	                maxEnding = 0; 
	            if (currentMax < maxEnding) 
	                currentMax = maxEnding; 
	        } 
	        return currentMax; //return the max that you found
	    } 
}
