
/*
 * Assignment 3
 * By: Toni Dunlap
 * Date: 10/7/2018
 * Collaborated with others in class
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

//Driver Program to run the application

public class Program3Driver {
	public static void main(String[] args)  {
		
		File file = new File(args[0]); //using the command line to read the file
		ArrayList<Integer> unarr = new ArrayList<Integer>();
		
		try {
			
			Scanner sc = new Scanner (file);
			
			while (sc.hasNext()) {
				unarr.add(sc.nextInt());
			}
			sc.close();
		}
		
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		
		ArrayList<Integer> arr = unarr;
		int sum = 0;
		
		//Sets timer that is recording the time it takes to complete the Kadane operation
		CpuTimer timer1 = new CpuTimer();
		for (int i = 0; i < 1000; i++) { //runs the program 1000 times
			if (i == 0) {
				sum = Kadane.maxCircularSum(unarr);
				continue;
			}
			Kadane.maxCircularSum(unarr);
		}
		
		double time1 = timer1.getElapsedCpuTime()/1000; //divide by 1000 to get the time it took approximately for each run
		System.out.println(unarr.size() + ", " + "K, " + time1 + ", " + sum);
		
		//Sets timer that is recording the time it takes to complete the Divide and Conquer Max Sub operation
		CpuTimer timer2 = new CpuTimer();
		for (int i = 0; i<1000; i++) {
			if (i == 0) {
				sum = DivideConquerMaxSub.maxCircularDivide(arr);
				continue;
			}
			DivideConquerMaxSub.maxCircularDivide(arr);
		}
		
		double time2 = timer2.getElapsedCpuTime()/1000; //divide by 1000 to get the time it took approximately for each run
		System.out.println(unarr.size() + ", " + "R, " + time2 + ", " + sum);
	}
}