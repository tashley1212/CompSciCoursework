
import java.lang.management.*;
/***  @author Mike Goss (mikegoss@cs.du.edu)**/
public class CpuTimer {
	ThreadMXBean bean;
	double startTimeSeconds;
	public CpuTimer() {
		bean = ManagementFactory.getThreadMXBean();
		assert bean.isCurrentThreadCpuTimeSupported() :
			"getCurrentThreadCpuTime not supported by this JVM, use a different"
			+ " JVM";
		startTimeSeconds = 1.0e-9 * (double) bean.getCurrentThreadCpuTime();
		}
	
	public double getElapsedCpuTime() {
		return 1.0e-9 * (double) bean.getCurrentThreadCpuTime() - startTimeSeconds;
	}
}