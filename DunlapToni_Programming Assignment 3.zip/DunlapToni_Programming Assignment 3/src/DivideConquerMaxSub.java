/*
 * Assignment 3
 * By: Toni Dunlap
 * Date: 10/7/2018
 * Collaborated with others in class
 */

import java.util.ArrayList;


public class DivideConquerMaxSub{	

//	//method to find the maximum possible sum using an array list.
//	public static int maxPosSum(ArrayList<Integer> arr, int low, int mid, int high) {
//		int sum = 0;
//		int left_sum = Integer.MIN_VALUE;
//		int maxL = 0; 
//		int maxR = 0;
//		//initializing variables 
//		
//		//starting in the middle of the list, and continuing as long as
//		for (int i = mid; i >= low; i--) {
//			sum = sum + arr.get(i);
//			if (sum > left_sum) {
//				left_sum = sum;
//				maxL = i;
//			}	
//		}
//		
//		sum = 0;
//		
//		int right_sum = Integer.MIN_VALUE;
//		for (int i = mid + 1; i <= high; i++) {
//			sum = sum + arr.get(i);
//			if (sum > right_sum) {
//				right_sum = sum;
//				maxR = i;
//			}
//		}
//			return left_sum + right_sum;
//		
//	}
	
	public static int maxSubArraySum(ArrayList<Integer> arr, int low, int high) {
		int lMidSum = Integer.MIN_VALUE;
		int rMidSum = Integer.MIN_VALUE;
		int sum = 0; //initializing these 3 variables
		
		if (low == high) {
			return arr.get(low);
		}
		
		int mid = low + (high - low)/2;
		//calculating the max sums on the left and right sides of the array
		int sumofMaxLeft = maxSubArraySum(arr, low, mid);
		int sumofMaxRight = maxSubArraySum(arr, mid + 1, high);
		
		//calculating the sum of the values to the left side of the mid point of the array list
		for (int i = mid; i>= low; i--) {
			sum += arr.get(i); //adding up sum of values in array list
			if (sum > lMidSum) {//checking to determine wich value is the max
				lMidSum = sum;
				
			}
			else {
				lMidSum = lMidSum;
			}
		}
			//reset the sum
			sum = 0;
			
			//calculating the sum of the values to the right side of the mid point of the array list			
		
		for (int i = mid + 1; i <= high; i++) {//checking to determine which value is the max
			sum += arr.get(i); //adding up sum of values in array list
			if (sum > rMidSum) {
				rMidSum = sum;
			}
			else {
				rMidSum = rMidSum;
			}
		}
		
		int max = Math.max(sumofMaxLeft, sumofMaxRight);
		return Math.max(max, (lMidSum + rMidSum)); //this will return which out of the 2 sums is bigger
	}
	
	public static int maxCircularDivide (ArrayList<Integer> arr) {
			
		int divideMax = maxSubArraySum(arr, 0, arr.size()-1); //recursive call to the above method
		
		int maxWithCE = 0;
		
		for (int i = 0; i < arr.size(); i++) { //utilizing a circular ArrayList
			maxWithCE += arr.get(i);
			arr.set(i, -(arr.get(i)));
		}
		
		maxWithCE += maxSubArraySum(arr, 0, arr.size()-1); //adds onto the value of the maxSubArray by going through the circular array list
		
		if (maxWithCE > divideMax) { //checking to see which sum is the largest, and returns the largest sum
			return maxWithCE;
		}
		else {
			return divideMax;
		}
	}
}