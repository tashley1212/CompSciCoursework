/*
 * @author: Toni Dunlap
 * date: 10/8/2018
 *  Assignment: Project 2
 */
package unstddraw;
import edu.princeton.cs.introcs.StdDraw;

public class UnStdDrawDriver {
	public static final int CANVAS_SIZE = 400;
	public static void main(String[] args)
	{
		//Set the canvas
		StdDraw.setCanvasSize(CANVAS_SIZE, CANVAS_SIZE);
		StdDraw.setXscale(0, 400);
		StdDraw.setYscale(0, 400);
	
		// Draws N-Polygon
		UnStdDraw draw = new UnStdDraw();
		StdDraw.setPenColor(UnStdDraw.getSlateBlue());
		UnStdDraw.filledRegularPolygon(75, 75, 70, 6);
		
		//Draws the spiral
		StdDraw.setPenColor(UnStdDraw.getRosyBrown());
		UnStdDraw.spiral(200, 200, 100, 8, 10);
						
		//Draws the ngon with several segments in order to make the circle
		StdDraw.setPenColor(UnStdDraw.getSeaGreen());
		UnStdDraw.filledRegularPolygon(325, 325, 70, 8);
		
			
		//Counts the methods
		System.out.println("Number of times Polygon Method Called: " + UnStdDraw.getNgonCount());
		System.out.println("Number of times Spiral Method Called: " + UnStdDraw.getSpiralCount());
	}
}
