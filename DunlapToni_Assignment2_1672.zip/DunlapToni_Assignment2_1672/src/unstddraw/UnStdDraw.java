package unstddraw;
import java.awt.Color;

import edu.princeton.cs.introcs.StdDraw;
/**
 * @author tashley1212
 *
 */
public class UnStdDraw {

	private static final Color SEA_GREEN = new Color(32,178,170);
	private static final Color ROSY_BROWN = new Color(188,143,143);
	private static final Color SLATE_BLUE = new Color(106,90,205);
	
	public static void filledRegularPolygon(double centerX, double centerY, double radius, int n) {
		double[] x = new double[n];
		double[] y = new double[n];
		for (int i = 0; i < n; i++) 
		{
			x[i] = centerX + radius * Math.cos(Math.toRadians((i+1)*(360.0/n)));
			y[i] = centerY + radius * Math.sin(Math.toRadians((i+1)*(360.0/n)));
			
			
		}
	
	StdDraw.filledPolygon(x, y);
	ngonCount += 1;
}
	
public static void spiral(double centerX, double centerY, double maxRadius, int spinRate, int numSegments) {
	//StdDraw.setPenRadius(0.05);
	double radiusSeg = (maxRadius/(numSegments*spinRate));
	double radius = 0.0;
	double[] x, y;
	x = new double[spinRate*numSegments];
	y = new double[spinRate*numSegments];
	double newX = centerX;
	double newY = centerY;
	
	for (int i = 0; i < numSegments*spinRate; ++i)
	{
		x[i] = centerX + (radius) * Math.cos(Math.toRadians((i)*(360.0/numSegments)));
		y[i] = centerY + (radius) * Math.sin(Math.toRadians((i)*(360.0/numSegments)));
		
		StdDraw.setPenRadius(0.01);
		
		StdDraw.line(newX, newY, x[i], y[i]);
		
		newX = x[i];
		newY = y[i];
		
		radius = radius + radiusSeg;
		
	}
	spiralCount += 1;
	}
//Ngon count
private static int ngonCount; 
//Accessors & Mutators 
public static int getNgonCount() {
	return ngonCount;
}

//public static void setNgonCount (int ngonCount) {
//	UnStdDraw.ngonCount = ngonCount;
//}

//Spiral Count
private static int spiralCount;

//Spiral Count Accessors & Mutators
public static int getSpiralCount() {
	return spiralCount;
}

//public static void setSpiralCount (int spiralCount) {
//	UnStdDraw.spiralCount = spiralCount;
//}

public static Color getSlateBlue() {
	return SLATE_BLUE;
}

public static Color getSeaGreen() {
	return SEA_GREEN;
}

public static Color getRosyBrown() {
	return ROSY_BROWN;
}
}