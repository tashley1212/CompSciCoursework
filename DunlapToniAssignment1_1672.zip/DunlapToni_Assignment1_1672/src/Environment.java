/*
 * @author: Toni Dunlap
 * Date: 1/18/2018 (redone for 9/24/2018)
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import edu.princeton.cs.introcs.StdDraw;


public class Environment {
	private int numOfRows; // this initiates the rows in the array
	private int numOfCols; // this initiates the columns in the array
	private Cell[][] arrayComplex; //this buildings the array neighboorhood

	public Environment(String filename) {
		Scanner file = null;
		try {
			file = new Scanner(new FileInputStream(filename));

		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
			System.exit(0);
		}// the above code scans to verify that the file imported is found and returns an error if it's not found


		numOfRows = file.nextInt();
		numOfCols = file.nextInt();
		arrayComplex = new Cell[numOfRows][numOfCols];

		for (int r = 0; r < numOfRows; r++) {
			for(int c = 0; c < numOfCols; c++) {
				int status = file.nextInt();
				arrayComplex [r][c] = new Cell (status == 1);	
			} // this portion of the code checks the status of each cell
		}
	}

	public void gridStart() {
		double scaleFactor = 1.0 / ((arrayComplex.length > arrayComplex[0].length) ? arrayComplex.length : arrayComplex[0].length);
		for (int r = 0; r < numOfRows; r++) {
			for (int c = 0; c < numOfCols; c++) {
				if (arrayComplex[r][c].getOccupied()) {
					StdDraw.setPenColor(StdDraw.BLACK);
					StdDraw.filledSquare(c * scaleFactor + scaleFactor / 2, r*scaleFactor + scaleFactor / 2, scaleFactor /2);
				}
		} // the above code colors in the squares that are occupied
	}
}
public void update() {
	Cell[][] nextGen = new Cell[numOfRows][numOfCols];
	for (int i = 0; i < numOfRows; i++) {
		for (int j = 0; j < numOfCols ; j++) {
			nextGen[i][j] = new Cell (alive(i,j));
		}
	}
	arrayComplex = nextGen; 
} // this portion of the code is what creates the births. The for loops goes through the array to verify the occupants of the 
// surrounding spaces.


public boolean alive(int r, int c) {
	int aliveNeighbors = neighborCount(r,c);
	if(aliveNeighbors < 2) {
		return false;
	} if(aliveNeighbors == 2) {
		return arrayComplex[r][c].getOccupied();
	} if(aliveNeighbors == 3) {
		return true;
	}
	return false;
} // checks whether the residents are alive and if a space is occupied

public int neighborCount(int i, int j) {
	int count = 0;
	for (int r_offset = -1; r_offset <= 1; r_offset++) {
		for (int c_offset = -1; c_offset <= 1; c_offset++)	{
			if (r_offset == 0 && c_offset == 0) {
				continue;
			}
			if(i + r_offset >= 0 && i + r_offset < arrayComplex.length) {
				if (j+c_offset >= 0 && j+c_offset < arrayComplex[0].length) {
					if (arrayComplex[i + r_offset][j + c_offset].getOccupied()) {
						count++;
					}
				}
			}
		}
	}
	return count;
}

public void runSimulation() {
	StdDraw.enableDoubleBuffering();

	while (true) {
		update();
		StdDraw.clear();
		gridStart();
		StdDraw.show();
		StdDraw.pause(1000); // adjusts the timing of the simulation
	}
} // the above is what prompts the program to start.
}


/* 
	public Environment(String s) {
		try {
			File f = new File(s);
			Scanner myScanner = new Scanner(f);
			numOfRows = myScanner.nextInt();
			numOfCols = myScanner.nextInt();
			arrayComplex = new Cell[numOfRows][numOfCols];
			for(int i = 0; i < numOfRows; i++) 
			{
				for (int j = 0; j < numOfCols; j++)
				{
					if(myScanner.nextInt() == 1)
					{
						arrayComplex[i][j] = new Cell(true);
					}
					else
					{
						arrayComplex[i][j] = new Cell(false);
					}
				}
			}
			myScanner.close();
		}
		catch (FileNotFoundException exc) {
			System.out.println("error");
		}
	}

	public void runSimulation() {
		show();
	}

	private void show()
	{
		for(int i = 0; i < numOfRows; i++) 
		{
			for (int j = 0; j < numOfCols; j++)
			{
				if (arrayComplex[i][j].getOccupied() == true)
					System.out.print(1);
				if (arrayComplex[i][j].getOccupied()== false);
					System.out.print(0);
				else {
						System.out.println("error");	
			}
			System.out.println();
		}

	}
}
 */

