/*
 * @author: Toni Dunlap
 * collaborated with Giselle
 * Date: 1/18/2018
 */

public class Cell {

	private boolean occupied;
	
	public Cell(boolean x) {
		occupied = x;
	}
	
	public boolean getOccupied() {
		return occupied;
	}
	
}
