/*
 * @author: Toni Dunlap
 * Date: 1/18/2018 (Redone for 9/24/2018)
 */


public class EnvironmentDriver {
	public static void main(String[] args)
	{
		String filename = "GameOfLife3.txt"; //works for all text files 
		Environment e = new	Environment(filename);
		e.runSimulation();
	}

}